from flask import Flask, request, redirect, session, jsonify, url_for
from flask import render_template_string
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Моковые данные для пользователей(в реальном приложении используется база данных)
users = {
    'admin': {'password': 'admin123', 'name': 'Администратор'},
    'user': {'password': 'user123', 'name': 'Обычный пользователь'}
}

# Данные для товаров
products = {
    1: {"id": 1, "name": "Хлопковая ткань \"Лето\"", "price": 850, "category": "fabrics", 
        "image": "/static/products/cotton_fabric_summer.jpg", 
        "description": "Качественная хлопковая ткань для летней одежды."},
    2: {"id": 2, "name": "Швейная машинка Mini", "price": 12490, "category": "tools", 
        "image": "/static/products/sewing_machine_mini.jpg", 
        "description": "Компактная швейная машинка для домашнего использования."},
    3: {"id": 3, "name": "Набор игл для швейной машинки", "price": 690, "category": "accessories", 
        "image": "/static/products/sewing_machine_needles_set.jpg", 
        "description": "Набор из 10 игл разного размера для швейных машин."},
    4: {"id": 4, "name": "Профессиональные ножницы", "price": 2350, "category": "tools", 
        "image": "/static/products/professional_scissors.jpg", 
        "description": "Острые профессиональные ножницы для раскроя тканей."},
    5: {"id": 5, "name": "Шелковая ткань Премиум", "price": 1200, "category": "fabrics", 
        "image": "/static/products/silk_fabric_premium.jpg", 
        "description": "Роскошная шелковая ткань для вечерних нарядов."},
    6: {"id": 6, "name": "Набор ниток (50 цветов)", "price": 890, "category": "threads", 
        "image": "/static/products/threads_set_50_colors.jpg", 
        "description": "Большой набор ниток различных цветов для любых проектов."}
}

categories = {
    "fabrics": {"name": "Ткани", "image": "/static/categories/fabrics_category.jpg"},
    "accessories": {"name": "Фурнитура", "image": "/static/categories/accessories_category.jpg"},
    "threads": {"name": "Нитки", "image": "/static/categories/threads_category.jpg"},
    "tools": {"name": "Инструменты", "image": "/static/categories/tools_category.jpg"}
}

blog_posts = [
    {
        "title": "Как выбрать ткань для летнего платья",
        "image": "/static/blog/choosing_fabric_for_summer_dress.jpg",
        "content": "Полезные советы по выбору ткани для летнего сезона"
    },
    {
        "title": "Как правильно ухаживать за шерстяными изделиями",
        "image": "/static/blog/caring_for_wool_products.jpg",
        "content": "Рекомендации по стирке и хранению шерстяных вещей"
    },
    {
        "title": "5 советов начинающим швеям",
        "image": "/static/blog/5_tips_for_beginner_seamstresses.jpg",
        "content": "Простые рекомендации для тех, кто только начинает шить"
    }
]

# Полный HTML шаблон для главной страницы
def get_full_html(content, cart_count=0, title="Иголка и Нитка - магазин швейных товаров", user=None):
    user_display = f'<span style="margin-right: 15px;">Привет, {user["name"]}!</span><a href="/logout" style="color: #8a5a44;">Выйти</a>' if user else '<a href="/login" style="color: #8a5a44;">Войти</a>'
    
    return f'''
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; font-family: 'Roboto', sans-serif; }}
        body {{ background-color: #f9f5f2; color: #333333; line-height: 1.6; }}
        a {{ text-decoration: none; color: inherit; }}
        .container {{ width: 100%; max-width: 1200px; margin: 0 auto; padding: 0 15px; }}
        header {{ background-color: #ffffff; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); position: sticky; top: 0; z-index: 100; }}
        .header-top {{ display: flex; justify-content: space-between; align-items: center; padding: 15px 0; }}
        .logo {{ font-size: 24px; font-weight: 700; color: #8a5a44; display: flex; align-items: center; }}
        .logo-icon {{ margin-right: 10px; font-size: 28px; }}
        .nav-menu {{ display: flex; list-style: none; }}
        .nav-menu li {{ margin: 0 15px; }}
        .nav-menu a {{ font-weight: 500; transition: color 0.3s; }}
        .nav-menu a:hover {{ color: #8a5a44; }}
        .header-icons {{ display: flex; align-items: center; }}
        .header-icons div {{ margin-left: 20px; cursor: pointer; font-size: 18px; position: relative; }}
        .cart-count {{ position: absolute; top: -10px; right: -10px; background-color: #8a5a44; color: white; border-radius: 50%; width: 18px; height: 18px; font-size: 12px; display: flex; justify-content: center; align-items: center; }}
        .btn {{ display: inline-block; background-color: #8a5a44; color: #ffffff; padding: 10px 20px; border-radius: 4px; margin-top: 15px; transition: background-color 0.3s; cursor: pointer; border: none; }}
        .btn:hover {{ background-color: #d8a886; }}
        .section-title {{ text-align: center; margin-bottom: 30px; font-size: 28px; color: #8a5a44; }}
        .categories {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 50px; }}
        .category-card {{ position: relative; height: 200px; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); transition: transform 0.3s; }}
        .category-card:hover {{ transform: translateY(-5px); }}
        .category-card img {{ width: 100%; height: 100%; object-fit: cover; }}
        .category-name {{ position: absolute; bottom: 0; left: 0; right: 0; background-color: rgba(138, 90, 68, 0.8); color: #ffffff; padding: 10px; text-align: center; font-weight: 500; }}
        .products {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 25px; margin-bottom: 50px; }}
        .product-card {{ background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); transition: transform 0.3s; }}
        .product-card:hover {{ transform: translateY(-5px); }}
        .product-image {{ height: 200px; overflow: hidden; }}
        .product-image img {{ width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s; }}
        .product-card:hover .product-image img {{ transform: scale(1.05); }}
        .product-info {{ padding: 15px; }}
        .product-title {{ font-weight: 500; margin-bottom: 10px; }}
        .product-price {{ color: #8a5a44; font-weight: 700; font-size: 18px; margin-bottom: 10px; }}
        .product-actions {{ display: flex; justify-content: space-between; }}
        .quantity-selector {{ display: flex; align-items: center; }}
        .quantity-btn {{ width: 30px; height: 30px; background-color: #f0f0f0; border: none; border-radius: 4px; cursor: pointer; }}
        .quantity-input {{ width: 40px; height: 30px; text-align: center; margin: 0 5px; border: 1px solid #ddd; border-radius: 4px; }}
        .advantages {{ background-color: #8a5a44; color: #ffffff; padding: 50px 0; margin-bottom: 50px; }}
        .advantages-container {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 30px; }}
        .advantage {{ text-align: center; }}
        .advantage i {{ font-size: 40px; margin-bottom: 15px; }}
        .advantage h3 {{ margin-bottom: 10px; }}
        .blog {{ margin-bottom: 50px; }}
        .blog-posts {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 25px; }}
        .blog-post {{ background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }}
        .blog-image {{ height: 200px; }}
        .blog-image img {{ width: 100%; height: 100%; object-fit: cover; }}
        .blog-content {{ padding: 20px; }}
        .blog-title {{ font-size: 18px; margin-bottom: 10px; }}
        .cart-table {{ width: 100%; border-collapse: collapse; margin-bottom: 30px; }}
        .cart-table th, .cart-table td {{ padding: 15px; text-align: left; border-bottom: 1px solid #ddd; }}
        .cart-table th {{ background-color: #f5f5f5; }}
        .cart-item-image {{ width: 80px; height: 80px; object-fit: cover; border-radius: 4px; }}
        .cart-total {{ text-align: right; font-size: 20px; font-weight: bold; margin-bottom: 20px; }}
        .form-group {{ margin-bottom: 20px; }}
        .form-label {{ display: block; margin-bottom: 5px; font-weight: 500; }}
        .form-input {{ width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; }}
        .form-input:focus {{ outline: none; border-color: #8a5a44; }}
        footer {{ background-color: #333333; color: #ffffff; padding: 50px 0 20px; }}
        .footer-content {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 30px; margin-bottom: 30px; }}
        .footer-column h3 {{ margin-bottom: 20px; font-size: 18px; }}
        .footer-column ul {{ list-style: none; }}
        .footer-column ul li {{ margin-bottom: 10px; }}
        .footer-column ul li a:hover {{ color: #d8a886; }}
        .social-icons {{ display: flex; gap: 15px; margin-top: 15px; }}
        .social-icons a {{ display: inline-block; width: 40px; height: 40px; background-color: #ffffff; border-radius: 50%; text-align: center; line-height: 40px; color: #333333; transition: background-color 0.3s; }}
        .social-icons a:hover {{ background-color: #d8a886; color: #ffffff; }}
        .copyright {{ text-align: center; padding-top: 20px; border-top: 1px solid #555555; }}
        
        @media (max-width: 992px) {{
            .categories, .products, .advantages-container, .blog-posts, .footer-content {{ grid-template-columns: repeat(2, 1fr); }}
        }}
        @media (max-width: 768px) {{
            .nav-menu {{ display: none; }}
        }}
        @media (max-width: 576px) {{
            .categories, .products, .advantages-container, .blog-posts, .footer-content {{ grid-template-columns: 1fr; }}
        }}
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-top">
                <a href="/" class="logo"><span class="logo-icon">🧵</span>Иголка и Нитка</a>
                <ul class="nav-menu">
                    <li><a href="/">Главная</a></li>
                    <li><a href="/category/fabrics">Ткани</a></li>
                    <li><a href="/category/accessories">Фурнитура</a></li>
                    <li><a href="/category/threads">Нитки</a></li>
                    <li><a href="/category/tools">Инструменты</a></li>
                </ul>
                <div class="header-icons">
                    <div class="search-icon" onclick="location.href='/search'">🔍</div>
                    <div class="user-icon">{user_display}</div>
                    <div class="cart-icon" onclick="location.href='/cart'">
                        🛒
                        {f'<span class="cart-count">{cart_count}</span>' if cart_count > 0 else ''}
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main>
        {content}
    </main>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>О магазине</h3>
                    <p>Иголка и Нитка - это магазин качественных швейных материалов и аксессуаров для профессиональных швей и любителей.</p>
                </div>
                <div class="footer-column">
                    <h3>Категории</h3>
                    <ul>
                        <li><a href="/category/fabrics">Ткани</a></li>
                        <li><a href="/category/accessories">Фурнитура</a></li>
                        <li><a href="/category/tools">Швейные машины</a></li>
                        <li><a href="/category/threads">Нитки</a></li>
                        <li><a href="/category/tools">Инструменты</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Полезные ссылки</h3>
                    <ul>
                        <li><a href="#">О нас</a></li>
                        <li><a href="#">Доставка и оплата</a></li>
                        <li><a href="#">Возврат товара</a></li>
                        <li><a href="#">Контакты</a></li>
                        <li><a href="#">Блог</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Контакты</h3>
                    <p>+7 (495) 123-45-67</p>
                    <p>info@igolka-nitka.ru</p>
                    <p>Москва, ул. Ткацкая, д. 15</p>
                    <div class="social-icons">
                        <a href="#">VK</a>
                        <a href="#">TG</a>
                        <a href="#">YT</a>
                    </div>
                </div>
            </div>
            <div class="copyright">
                <p>© 2023 Иголка и Нитка. Все права защищены.</p>
            </div>
        </div>
    </footer>

    <script>
        function addToCart(productId) {{
            const quantity = document.getElementById(`quantity-${{productId}}`)?.value || 1;
            
            fetch(`/add_to_cart/${{productId}}`, {{
                method: 'POST',
                headers: {{
                    'Content-Type': 'application-x-www-form-urlencoded',
                }},
                body: `quantity=${{quantity}}`
            }})
            .then(response => response.json())
            .then(data => {{
                if (data.success) {{
                    alert(data.message);
                    const cartCountElement = document.querySelector('.cart-count');
                    if (cartCountElement) {{
                        cartCountElement.textContent = data.cart_count;
                    }} else if (data.cart_count > 0) {{
                        const cartIcon = document.querySelector('.cart-icon');
                        const countElement = document.createElement('span');
                        countElement.className = 'cart-count';
                        countElement.textContent = data.cart_count;
                        cartIcon.appendChild(countElement);
                    }}
                }} else {{
                    alert('Ошибка: ' + data.message);
                }}
            }})
            .catch(error => {{
                console.error('Error:', error);
                alert('Произошла ошибка при добавлении товара в корзину');
            }});
        }}

        function increaseQuantity(productId) {{
            const input = document.getElementById(`quantity-${{productId}}`);
            input.value = parseInt(input.value) + 1;
        }}
        
        function decreaseQuantity(productId) {{
            const input = document.getElementById(`quantity-${{productId}}`);
            if (parseInt(input.value) > 1) {{
                input.value = parseInt(input.value) - 1;
            }}
        }}

        function removeFromCart(productId) {{
            fetch(`/remove_from_cart/${{productId}}`, {{
                method: 'POST',
            }})
            .then(response => response.json())
            .then(data => {{
                if (data.success) {{
                    location.reload();
                }} else {{
                    alert('Ошибка: ' + data.message);
                }}
            }})
            .catch(error => {{
                console.error('Error:', error);
                alert('Произошла ошибка при удалении товара из корзины');
            }});
        }}
    </script>
</body>
</html>
'''

# Маршруты
@app.route('/')
def index():
    popular_products = [products[i] for i in range(1, 5)]
    
    if 'cart' not in session:
        session['cart'] = {}
    
    cart_count = sum(session['cart'].values()) if session['cart'] else 0
    user = session.get('user')
    
    content = f'''
    <section class="hero-slider">
        <div class="slide active" style="background-image: url('https://placehold.co/1200x500/8a5a44/ffffff/png?text=Иголка+и+Нитка+—+магазин+швейных+товаров');">
            <div class="container">
                <div class="slide-content">
                    <h2>Качественные ткани для вашего творчества</h2>
                    <p>Широкий ассортимент тканей, фурнитуры и аксессуаров для шитья</p>
                    <a href="/category/fabrics" class="btn">Подробнее</a>
                </div>
            </div>
        </div>
    </section>

    <section class="container">
        <h2 class="section-title">Категории товаров</h2>
        <div class="categories">
            <a href="/category/fabrics" class="category-card">
                <img src="{categories['fabrics']['image']}" alt="Ткани">
                <div class="category-name">Ткани</div>
            </a>
            <a href="/category/accessories" class="category-card">
                <img src="{categories['accessories']['image']}" alt="Фурнитура">
                <div class="category-name">Фурнитура</div>
            </a>
            <a href="/category/threads" class="category-card">
                <img src="{categories['threads']['image']}" alt="Нитки">
                <div class="category-name">Нитки</div>
            </a>
            <a href="/category/tools" class="category-card">
                <img src="{categories['tools']['image']}" alt="Инструменты">
                <div class="category-name">Инструменты</div>
            </a>
        </div>
    </section>

    <section class="container">
        <h2 class="section-title">Популярные товары</h2>
        <div class="products">
            {''.join([f'''
            <div class="product-card">
                <div class="product-image">
                    <img src="{product['image']}" alt="{product['name']}">
                </div>
                <div class="product-info">
                    <h3 class="product-title">{product['name']}</h3>
                    <div class="product-price">{product['price']} ₽</div>
                    <div class="product-actions">
                        <div class="quantity-selector">
                            <button class="quantity-btn" onclick="decreaseQuantity({product['id']})">-</button>
                            <input type="number" id="quantity-{product['id']}" class="quantity-input" value="1" min="1">
                            <button class="quantity-btn" onclick="increaseQuantity({product['id']})">+</button>
                        </div>
                        <button class="btn" onclick="addToCart({product['id']})">В корзину</button>
                    </div>
                </div>
            </div>
            ''' for product in popular_products])}
        </div>
    </section>

    <section class="advantages">
        <div class="container">
            <div class="advantages-container">
                <div class="advantage">
                    <i>🚚</i>
                    <h3>Быстрая доставка</h3>
                    <p>Доставка по всей России от 1 дня</p>
                </div>
                <div class="advantage">
                    <i>💯</i>
                    <h3>Гарантия качества</h3>
                    <p>Все товары проходят строгий контроль</p>
                </div>
                <div class="advantage">
                    <i>💳</i>
                    <h3>Удобная оплата</h3>
                    <p>Наличные, карты, онлайн-платежи</p>
                </div>
                <div class="advantage">
                    <i>📞</i>
                    <h3>Поддержка 24/7</h3>
                    <p>Консультации по выбору товаров</p>
                </div>
            </div>
        </div>
    </section>

    <section class="container blog">
        <h2 class="section-title">Полезные статьи</h2>
        <div class="blog-posts">
            {''.join([f'''
            <div class="blog-post">
                <div class="blog-image">
                    <img src="{post['image']}" alt="{post['title']}">
                </div>
                <div class="blog-content">
                    <h3 class="blog-title">{post['title']}</h3>
                    <p>{post['content']}</p>
                    <a href="#" class="btn">Читать далее</a>
                </div>
            </div>
            ''' for post in blog_posts])}
        </div>
    </section>
    '''
    
    return get_full_html(content, cart_count, user=user)

@app.route('/category/<category_name>')
def category(category_name):
    if category_name not in categories:
        return redirect('/')
    
    category_products = [p for p in products.values() if p['category'] == category_name]
    
    if 'cart' not in session:
        session['cart'] = {}
    
    cart_count = sum(session['cart'].values()) if session['cart'] else 0
    user = session.get('user')
    
    content = f'''
    <div class="container" style="padding: 40px 0;">
        <h2 class="section-title">{categories[category_name]['name']}</h2>
        
        {f'''
        <div class="products">
            {''.join([f'''
            <div class="product-card">
                <div class="product-image">
                    <img src="{product['image']}" alt="{product['name']}">
                </div>
                <div class="product-info">
                    <h3 class="product-title">{product['name']}</h3>
                    <div class="product-price">{product['price']} ₽</div>
                    <div class="product-actions">
                        <div class="quantity-selector">
                            <button class="quantity-btn" onclick="decreaseQuantity({product['id']})">-</button>
                            <input type="number" id="quantity-{product['id']}" class="quantity-input" value="1" min="1">
                            <button class="quantity-btn" onclick="increaseQuantity({product['id']})">+</button>
                        </div>
                        <button class="btn" onclick="addToCart({product['id']})">В корзину</button>
                    </div>
                </div>
            </div>
            ''' for product in category_products])}
        </div>
        ''' if category_products else '''
        <p style="text-align: center; padding: 40px;">В этой категории пока нет товаров</p>
        '''}
    </div>
    '''
    
    return get_full_html(content, cart_count, f"{categories[category_name]['name']} - Иголка и Нитка", user=user)

# Маршрут для поиска
@app.route('/search')
def search():
    query = request.args.get('q', '')
    
    if 'cart' not in session:
        session['cart'] = {}
    
    cart_count = sum(session['cart'].values()) if session['cart'] else 0
    user = session.get('user')
    
    if query:
        search_results = [p for p in products.values() if query.lower() in p['name'].lower() or query.lower() in p['description'].lower()]
    else:
        search_results = []
    
    content = f'''
    <div class="container" style="padding: 40px 0;">
        <h2 class="section-title">Поиск товаров</h2>
        
        <form action="/search" method="GET" style="margin-bottom: 30px; display: flex;">
            <input type="text" name="q" value="{query}" class="form-input" placeholder="Введите название товара..." style="margin-right: 10px;">
            <button type="submit" class="btn">Найти</button>
        </form>
        
        {f'''
        <h3>Результаты поиска для "{query}"</h3>
        {f'''
        <div class="products">
            {''.join([f'''
            <div class="product-card">
                <div class="product-image">
                    <img src="{product['image']}" alt="{product['name']}">
                </div>
                <div class="product-info">
                    <h3 class="product-title">{product['name']}</h3>
                    <div class="product-price">{product['price']} ₽</div>
                    <div class="product-actions">
                        <div class="quantity-selector">
                            <button class="quantity-btn" onclick="decreaseQuantity({product['id']})">-</button>
                            <input type="number" id="quantity-{product['id']}" class="quantity-input" value="1" min="1">
                            <button class="quantity-btn" onclick="increaseQuantity({product['id']})">+</button>
                        </div>
                        <button class="btn" onclick="addToCart({product['id']})">В корзину</button>
                    </div>
                </div>
            </div>
            ''' for product in search_results])}
        </div>
        ''' if search_results else '<p>Товары не найдены</p>'}
        ''' if query else '<p>Введите поисковый запрос</p>'}
    </div>
    '''
    
    return get_full_html(content, cart_count, f"Поиск - Иголка и Нитка", user=user)

# Маршрут для авторизации
@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'cart' not in session:
        session['cart'] = {}
    
    cart_count = sum(session['cart'].values()) if session['cart'] else 0
    user = session.get('user')
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username in users and users[username]['password'] == password:
            session['user'] = users[username]
            session['user']['username'] = username
            session.modified = True  # Важно: помечаем сессию как измененную
            return redirect('/')
        else:
            error = "Неверное имя пользователя или пароль"
            content = f'''
            <div class="container" style="padding: 40px 0;">
                <h2 class="section-title">Вход в систему</h2>
                <form method="POST" style="max-width: 400px; margin: 0 auto;">
                    <div class="form-group">
                        <label class="form-label">Имя пользователя</label>
                        <input type="text" name="username" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Пароль</label>
                        <input type="password" name="password" class="form-input" required>
                    </div>
                    <button type="submit" class="btn">Войти</button>
                    <p style="color: red; margin-top: 10px;">{error}</p>
                </form>
            </div>
            '''
            return get_full_html(content, cart_count, "Вход - Иголка и Нитка", user=user)
    
    content = '''
    <div class="container" style="padding: 40px 0;">
        <h2 class="section-title">Вход в систему</h2>
        <form method="POST" style="max-width: 400px; margin: 0 auto;">
            <div class="form-group">
                <label class="form-label">Имя пользователя</label>
                <input type="text" name="username" class="form-input" required>
            </div>
            <div class="form-group">
                <label class="form-label">Пароль</label>
                <input type="password" name="password" class="form-input" required>
            </div>
            <button type="submit" class="btn">Войти</button>
            <p style="margin-top: 15px;">Тестовые пользователи: admin/admin123, user/user123</p>
        </form>
    </div>
    '''
    
    return get_full_html(content, cart_count, "Вход - Иголка и Нитка", user=user)

@app.route('/logout')
def logout():
    session.pop('user', None)
    session.modified = True  # Важно: помечаем сессию как измененную
    return redirect('/')

# Маршрут для корзины
@app.route('/cart')
def cart():
    if 'cart' not in session:
        session['cart'] = {}
    
    cart_items = []
    total = 0
    cart_count = sum(session['cart'].values()) if session['cart'] else 0
    user = session.get('user')
    
    for product_id, quantity in session['cart'].items():
        product = products.get(int(product_id))
        if product:
            item_total = product['price'] * quantity
            total += item_total
            cart_items.append({
                'product': product,
                'quantity': quantity,
                'total': item_total
            })
    
    content = f'''
    <div class="container" style="padding: 40px 0;">
        <h2 class="section-title">Корзина покупок</h2>
        
        {f'''
        <table class="cart-table">
            <thead>
                <tr>
                    <th>Товар</th>
                    <th>Цена</th>
                    <th>Количество</th>
                    <th>Итого</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                {''.join([f'''
                <tr>
                    <td>
                        <img src="{item['product']['image']}" alt="{item['product']['name']}" class="cart-item-image">
                        {item['product']['name']}
                    </td>
                    <td>{item['product']['price']} ₽</td>
                    <td>{item['quantity']}</td>
                    <td>{item['total']} ₽</td>
                    <td>
                        <button class="btn" onclick="removeFromCart({item['product']['id']})" style="background-color: #ff4444;">Удалить</button>
                    </td>
                </tr>
                ''' for item in cart_items])}
            </tbody>
        </table>
        
        <div class="cart-total">
            Общая сумма: {total} ₽
        </div>
        
        <div style="text-align: right;">
            <a href="/checkout" class="btn">Оформить заказ</a>
        </div>
        ''' if cart_items else '''
        <p style="text-align: center; padding: 40px;">Ваша корзина пуста</p>
        <div style="text-align: center;">
            <a href="/" class="btn">Вернуться к покупкам</a>
        </div>
        '''}
    </div>
    '''
    
    return get_full_html(content, cart_count, "Корзина - Иголка и Нитка", user=user)

# Маршрут для оформления заказа
@app.route('/checkout')
def checkout():
    if 'cart' not in session or not session['cart']:
        return redirect('/cart')
    
    cart_count = sum(session['cart'].values()) if session['cart'] else 0
    user = session.get('user')
    
    if not user:
        return redirect('/login')
    
    content = '''
    <div class="container" style="padding: 40px 0;">
        <h2 class="section-title">Оформление заказа</h2>
        
        <form style="max-width: 600px; margin: 0 auto;">
            <div class="form-group">
                <label class="form-label">ФИО</label>
                <input type="text" class="form-input" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" class="form-input" required>
            </div>
            <div class="form-group">
                <label class="form-label">Телефон</label>
                <input type="tel" class="form-input" required>
            </div>
            <div class="form-group">
                <label class="form-label">Адрес доставки</label>
                <textarea class="form-input" rows="3" required></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Способ оплаты</label>
                <select class="form-input" required>
                    <option value="">Выберите способ оплаты</option>
                    <option value="card">Банковская карта</option>
                    <option value="cash">Наличные при получении</option>
                    <option value="online">Онлайн-платеж</option>
                </select>
            </div>
            <button type="submit" class="btn">Подтвердить заказ</button>
        </form>
    </div>
    '''
    
    return get_full_html(content, cart_count, "Оформление заказа - Иголка и Нитка", user=user)

# API для работы с корзиной
@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):
    if product_id not in products:
        return jsonify({'success': False, 'message': 'Товар не найден'})
    
    if 'cart' not in session:
        session['cart'] = {}
    
    quantity = int(request.form.get('quantity', 1))
    
    if str(product_id) in session['cart']:
        session['cart'][str(product_id)] += quantity
    else:
        session['cart'][str(product_id)] = quantity
    
    session.modified = True  # Важно: помечаем сессию как измененную
    
    cart_count = sum(session['cart'].values())
    
    return jsonify({
        'success': True, 
        'message': f'Товар "{products[product_id]["name"]}" добавлен в корзину',
        'cart_count': cart_count
    })

@app.route('/remove_from_cart/<int:product_id>', methods=['POST'])
def remove_from_cart(product_id):
    if 'cart' not in session:
        session['cart'] = {}
    
    if str(product_id) in session['cart']:
        del session['cart'][str(product_id)]
        session.modified = True  # Важно: помечаем сессию как измененную
        return jsonify({'success': True, 'message': 'Товар удален из корзины'})
    
    return jsonify({'success': False, 'message': 'Товар не найден в корзине'})

# Запуск приложения
app.run(host='0.0.0.0', port=5000, debug=True)